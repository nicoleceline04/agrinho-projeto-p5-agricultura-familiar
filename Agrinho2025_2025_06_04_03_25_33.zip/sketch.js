let fase = 0;
let tempoFase = 0;

function setup() {
  createCanvas(600, 400); // Canvas menor agora
  textAlign(CENTER, CENTER);
  textSize(18);
}

function draw() {
  background(220);
  tempoFase++;

  if (tempoFase > 300) { // Troca de fase a cada 5 segundos
    fase++;
    tempoFase = 0;
  }

  if (fase === 0) {
    // Fase 1 - Agricultor planta
    drawCampo();
    drawAgricultor();
    fill(0);
    text("A agricultura familiar começa no campo...", width / 2, 40);
    } else if (fase === 1) {
    // Fase 2 - Alimento crescendo
    drawCampo();
    drawPlantas(tempoFase);
    fill(0);
    text("Com cuidado, o alimento cresce saudável.", width / 2, 40);
  } else if (fase === 2) {
    // Fase 3 - Caminhão leva para a cidade
    drawCaminhao(tempoFase);
    fill(0);
    text("O agricultor transporta a colheita até a cidade.", width / 2, 40);
  } else if (fase === 3) {
    // Fase 4 - Feira e consumo
    drawCidade();
  } else {
    // Mensagem final
    background(180, 255, 180);
    fill(0);
    textSize(24);
    text("A agricultura familiar alimenta o Brasil.", width / 2, height / 2 - 20);
    textSize(18);
    text("Valorize quem cultiva o que chega à sua mesa.", width / 2, height / 2 + 20);
  }
}

// --- Desenhos auxiliares ---
function drawCampo() {
  background("#C1E7E3");
  fill(100, 180, 80);
  rect(0, 300, width, 100); // chão
}

function drawAgricultor() {
  // Cabeça
  fill(255, 220, 180);
  ellipse(160, 245, 25, 25); // rosto

  // Chapéu de palha
  fill(210, 180, 80);
  rect(150, 225, 20, 10);    // topo do chapéu
  ellipse(160, 235, 40, 10); // aba do chapéu

  // Corpo
  fill(80, 120, 200); // camisa azul
  rect(145, 260, 30, 40); // tronco

  // Braços
  fill(80, 120, 200);
  rect(137, 263, 8, 30); // braço esquerdo
  rect(175, 263, 8, 30); // braço direito

  // Pernas
  fill(60, 60, 60); // calça
  rect(145, 300, 10, 30); // perna esquerda
  rect(165, 300, 10, 30); // perna direita

  // Botas
  fill(100, 50, 0);
  rect(145, 330, 10, 5);
  rect(165, 330, 10, 5);
}

function drawPlantas(t) {
  drawCampo();

  let maxAltura = 60;
  let altura = map(t, 0, 300, 10, maxAltura);
  let folhaTamanho = map(t, 0, 300, 5, 20);

  for (let i = 0; i < 5; i++) {
    let x = 100 + i * 80;
    let baseY = 300;

    // Caule - linha fina com leve curva (bezier)
    stroke(34, 139, 34);
    strokeWeight(3);
    noFill();
    bezier(
      x, baseY,
      x - 10, baseY - altura / 2,
      x + 10, baseY - altura / 1.5,
      x, baseY - altura
    );

    noStroke();
    fill(34, 139, 34);

    // Folhas - 2 de cada lado do caule
    // Folha esquerda
    ellipse(x - folhaTamanho / 2, baseY - altura * 0.75, folhaTamanho, folhaTamanho / 2);
    ellipse(x - folhaTamanho / 1.5, baseY - altura * 0.5, folhaTamanho * 0.8, folhaTamanho / 3);

    // Folha direita
    ellipse(x + folhaTamanho / 2, baseY - altura * 0.75, folhaTamanho, folhaTamanho / 2);
    ellipse(x + folhaTamanho / 1.5, baseY - altura * 0.5, folhaTamanho * 0.8, folhaTamanho / 3);

    // Pequena flor no topo
    fill(255, 100, 100, map(t, 0, 300, 0, 255));
    ellipse(x, baseY - altura - 5, folhaTamanho / 1.5, folhaTamanho / 1.5);
  }
}

function drawCaminhao(x) {
  let y = 280;

  // Carroceria
  fill(200, 100, 50);
  rect(x, y, 100, 40, 5); // carga

  // Cabine
  fill(150, 0, 0);
  rect(x + 100, y + 10, 40, 30, 5); // corpo da cabine
  fill(255);
  rect(x + 110, y + 15, 20, 15, 3); // janela

  // Farol
  fill(255, 255, 100);
  ellipse(x + 142, y + 25, 8, 8);

  // Rodas
  fill(50);
  ellipse(x + 20, y + 45, 20, 20);
  ellipse(x + 120, y + 45, 20, 20);

  // Centro das rodas
  fill(180);
  ellipse(x + 20, y + 45, 8, 8);
  ellipse(x + 120, y + 45, 8, 8);
}

function drawCidade(x) {
  let yBase = 280;

  // Céu de fundo
  background("#7186b2"); // azul claro
  
  // Chão (grama ou terra)
fill("#6b8e23"); // verde oliva, por exemplo
rect(0, yBase + 40, width, height - (yBase + 40)); // retângulo do chão abaixo da estrada

  // Cidade (prédios mais afastados da feira)
  for (let i = 2; i < 5; i++) { // começa do i = 2 pra pular os dois primeiros
    let px = 80 + i * 90;
    let ph = 80 + i * 10;

    fill(180); // cor do prédio
    rect(px, yBase - ph, 50, ph); // prédio

    fill(255, 255, 100); // janelas
    rect(px + 10, yBase - ph + 10, 10, 10);
    rect(px + 30, yBase - ph + 10, 10, 10);
    rect(px + 10, yBase - ph + 30, 10, 10);
    rect(px + 30, yBase - ph + 30, 10, 10);
  }

  // Feira do lado esquerdo
  for (let i = 0; i < 3; i++) {
    let bx = 40 + i * 60;
    let by = yBase - 30;

    // Banca
    fill(220);
    rect(bx, by, 40, 30); // base

    // Toldo colorido
    fill(255 - i * 30, 100 + i * 50, 100);
    rect(bx, by - 20, 40, 20, 3); // toldo

    // Frutas/legumes (caixinhas coloridas)
    fill(0, 200, 0); // verde (alface)
    rect(bx + 5, by + 5, 10, 10);
    fill(255, 0, 0); // vermelho (tomate)
    rect(bx + 20, by + 5, 10, 10);
    fill(255, 165, 0); // laranja (cenoura)
    rect(bx + 12, by + 15, 10, 10);
  }

  // Estrada
  fill(80);
  rect(0, yBase, width, 40);

  // Faixa amarela
  fill(255, 255, 0);
  for (let i = 0; i < width; i += 40) {
    rect(i + 10, yBase + 15, 20, 5);
  }

  // Texto
  fill(0);
  text("Na cidade, os alimentos chegam frescos às feiras.", width / 2, 360);
}
